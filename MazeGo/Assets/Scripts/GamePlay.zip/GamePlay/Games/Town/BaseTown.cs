﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 防御塔基类.
/// </summary>
public class BaseTown : Town
{
    #region PublicField
    #endregion

    #region PrivateField
    #endregion

    #region PublicMethod
    #endregion

    #region PrivateMethod
    protected void Start()
    {
        base.Start();
    }

    protected void Update()
    {
        base.Update();
    }
    #endregion
}
