﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 塔防模式下, 激光塔.
/// </summary>

public class LaserTown : Town
{
    #region PublicField
    #endregion

    #region PrivateField
    #endregion

    #region PublicMethod
    #endregion

    #region PrivateMethod
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    #endregion


}
