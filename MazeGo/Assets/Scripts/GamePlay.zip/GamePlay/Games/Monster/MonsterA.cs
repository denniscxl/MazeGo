﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterA : Monster
{
    #region PublicField
    #endregion

    #region PrivateField
    #endregion

    #region PublicMethod
    #endregion

    #region PrivateMethod
    protected void Start()
    {
        base.Start();
    }
    #endregion
}
