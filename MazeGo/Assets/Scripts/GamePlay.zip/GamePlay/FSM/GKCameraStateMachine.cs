﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GKStateMachine;
public class GKCameraStateMachine : GKStateMachineBase<MachineStateID>
{
    
}